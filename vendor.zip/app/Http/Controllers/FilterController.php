<?php

namespace App\Http\Controllers;

use App\Http\Resources\User\UsersWithByTypesFiltersREsource;
use App\Http\Resources\User\UsersWithFiltersREsource;
use Carbon\Carbon;
use App\Models\User;
use App\Models\Order;
use App\Models\Filter;
use Illuminate\Http\Request;

class FilterController extends Controller
{
    public function getFilteredUsers(Request $request)
    {
        $query = User::query()->where('status', 'active');
        Filter::getfilters();

        if ($request->has('filter')) {
            $filterType = $request->input('filter');
            if ($filterType == 'today') {
                $date = Carbon::now()->startOfDay();
            } elseif ($filterType == 'tomorrow') {
                $date = Carbon::now()->startOfDay()->addDay();
            } elseif ($filterType == 'expired') {
                $date = Carbon::yesterday()->startOfDay();
            }

            $filters = Filter::getfilters();
            $userIds = $filters->map(function ($filter) use ($date, $filterType) {
                $changedAt = Carbon::parse($filter->changed_at);

                if ($filterType == 'today' || $filterType == 'tomorrow') {
                    $expired = $changedAt->copy()->addMonths($filter->expiration_date)->endOfDay();
                    if ($expired->isSameDay($date)) {
                        return $filter;
                    }
                } elseif ($filterType == 'expired') {
                    $expired = $changedAt->copy()->addMonths($filter->expiration_date)->endOfDay();
                    if ($expired->lessThan($date)) {
                        return $filter;
                    }
                }
            })->pluck('user_id')->toArray();
            $query->whereIn('id', $userIds);
        }

        if ($request->has('search')) {
            $search = $request->input('search');
            $query->where(function ($q) use ($search) {
                $q->where('phone', 'like', "%{$search}%")
                    ->orWhere('name', 'like', "%{$search}%")
                    ->orWhere('address', 'like', "%{$search}%");
            });
        }

        $users = $query->paginate(15);

        return response()->json([
            'success' => true,
            'total' => $users->total(),
            'per_page' => $users->perPage(),
            'current_page' => $users->currentPage(),
            'last_page' => $users->lastPage(),
            'data' => UsersWithByTypesFiltersResource::collection($users)
        ]);
    }

    public function update(Filter $filter)
    {
        if ($filter->update(['changed_at' => Carbon::now()])) {
            return response()->json([
                'success' => true,
                'message' => 'Filter updated successfully'
            ], 200);
        }
    }

    // public function getfilters(){
    //     $filters = Filter::getfilters();
    //     return response()->json([
    //        'success' => true,
    //         'data' => $filters
    //     ]);
    // }

}
